#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <Windows.h>

using namespace std;
/*
int main()
{
	
	// M�todo para localizar um tipo de nome neste caso tenta encontrar os modelos R2
	char str[][5] = { "R2D2" , "C3PO" , "R2A6" };
	int n;
	puts("Looking for R2 astromech droids...");
	for (n = 0; n<3; n++)
		if (strncmp(str[n], "R2xx", 2) == 0)
		{
			printf("found %s\n", str[n]);
		}
	return 0;	
	
}

*/

// basic file operations

/*
int main() {
	string line;
	ifstream myfile("example.txt");

	string nomeProcura;

	if (myfile.is_open())
	{
		
		cout << "Qual e o nome que queres que eu encontre:"; // indicar o nome do aluno
		cin >> nomeProcura; // inserir o nome
		

		
		size_t posicao;
		while (myfile.good())
		{
			getline(myfile, line);	// escreve uma string
			posicao = line.find(nomeProcura); // come�a a procurar

			if (posicao != string::npos) // npos indica que n�o foi encontra
			{
				cout << "Foi encontrado"<< endl;
				while (getline(myfile, nomeProcura))
				{
					cout << nomeProcura;
				}
				break;
			}
			else
			{
				cout << "Nao foi encontrado" << endl;
			}
		}
	}
	
		//while(getline(myfile, line)) // enquanto escreve at� ao fim
		//cout << line << endl; // mostra como output o que vier do texto

	else cout << "Unable to open file";

	return 0;
}

*/

//const int tamanho = 500;
//int main()
//{
//	fstream ficheiro;
//	char temp [tamanho];
//	wstring input;
//	string line (temp);
//
//	ficheiro.open("Refeicoes.txt", ios::in);
//
//	if (!ficheiro)
//	{
//		cout << "Erro detectado por favor tenta reparar" << endl;
//		exit(EXIT_FAILURE);
//	}
//
//	char *alm = "Almoco";
//	char *jnt = "Jantar";
//
//
//	if (ficheiro.is_open())
//	{
//		while(getline(ficheiro, line))
//		{
//			cout << line << endl;
//		}
//	 ficheiro.close();
//	}
//}

//fstream& GotoLine(fstream& file, unsigned int num)
//{
//	file.seekg(ios::beg);
//	for (int i = 0; i < num - 1; ++i)
//	{
//		file.ignore(numeric_limits<streamsize>max(), '\n');
//	}
//	return file;
//}

/*
int main()
{
	unsigned int dia, mes, ano;
	bool repete = true;


	while (repete)
	{
		cout << "Por favor insira o ano: ";
		cin >> ano;
		if ( ano >= 2016 && ano <= 2120 )
		{
				repete = false;
		}
		else 
		{
				cout << "Valor incorrecto\n";		// se for negativo o ano ou se ultrapassar entre os valores inseridos
				repete;
		}
	}

	repete = true; // forca para true

	while (repete)
	{
		cout << "Por favor insira o mes: ";
		cin >> mes;
		if (mes >= 1 && mes <= 12)
		{
			repete = false;
		}
		else // se for negativo ou se ultrapassar o limite ent�o volta a repetir
		{
			cout << "Valor incorrecto\n"; 
			repete;
		}

	}

	repete = true; // forca para true
	while(repete)
	{
		if ((ano % 400 == 0) || (ano % 4 == 0 && ano % 100 != 0))
		{
			cout << "O ano e bissexto\n";
			cout << "Por favor insira o dia: ";
			cin >> dia;
			if (dia >= 1 && dia <= 29 && mes == 2)
			{
				repete = false;
			}
			else if (dia >= 1 && dia <= 31 && (mes == 1 || mes == 3 || mes == 5 || mes == 7|| mes == 8 ||  mes == 10 || mes == 12))
			{
				repete = false;
			}
			else if (dia >= 1 && dia <= 30 && (mes == 4 || mes == 6 || mes == 9 || mes == 11))
			{
				repete = false;
			}
			else // se nao for nenhum caso
			{
				repete;
				cout << "Valor incorrecto\n";
			}
		}
		else
		{
			cout << "O ano nao e bissexto\n";
			cout << "Por favor insira o dia: ";
			cin >> dia;
			if (dia >= 1 && dia <= 28 && mes == 2)
			{
				repete = false;
			}
			else if (dia >= 1 && dia <= 31 && (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12))
			{
				repete = false;
			}
			else if (dia >= 1 && dia <= 30 && (mes == 4 || mes == 6 || mes == 9 || mes == 11))
			{
				repete = false;
			}
			else {	// se for negativo ou se ultrapassar o limite ent�o volta a repetir
				repete;
				cout << "Valor incorrecto\n";
			}
		}
	}


	cout << "A refeicao sera na data: " << dia << " / " << mes << " / " << ano << endl;
	


}*/

//int main()
//{
//	fstream file;
//	vector<string> v;
//	file.open("Refeicoes.txt");
//	string tmp;
//	while (!file.eof())
//	{
//		file >> tmp;
//		v.push_back(tmp);
//	}
//	for (vector<string>::iterator i = v.begin(); i != v.end(); i++)
//	{
//		cout << *i << endl;
//	}
//	file.close();
//	return 0;
//}

/*
const int tamanho = 500;
int main()
{
	ifstream fin("Refeicoes.txt");
	
	char temp[tamanho];
	string line;

	int dia ;
	int mes ; 
	int ano ;
	char *alm = "Almoco";
	char *jnt = "Jantar";

	cout << "Insira o dia: ";
	cin >> dia;
	cout << "Insira o mes: ";
	cin >> mes;
	cout << "Insira o ano: ";
	cin >> ano;

	string dia_String = to_string(dia);
	string mes_String = to_string(mes);
	string ano_String = to_string(ano);

	string joining = dia_String + mes_String + ano_String;
	string encontrarData;

	char resposta;
	bool almoco;

	cout << "Deseja almoco?";
	cin >> resposta;

	if (resposta == 's' || resposta == 'S')
	{
		almoco = true;
	}
	else
	{
		almoco = false;
	}


	if (fin.is_open())
	{
		for (int i = 1; !fin.eof(); i++)
		{
			getline(fin, line);
			goto Condicao;




			Condicao:
			if (line == joining)
			{	
				goto EscolhaEpoca;
			}
			//else goto Cancelar;
			
			


		//EscolhaEpoca:
		//	if (almoco == true)
		//	{
		//		if (line == alm) // procura a letra almoco
		//		{
		//			goto Contador;
		//		}
		//	}
		//	
		}
		
		//goto Cancelar;
	} 
	else {
		cout << "ERROR FILE NOT FOUND" << endl;
	}

	//goto Cancelar;


EscolhaEpoca:
	while (!fin.eof())
	{
		if (almoco = true)
		{
			if (line == alm) // procura a letra almoco
			{
				goto Contador;
			}
		}
	}

Contador:
	for (int j = 0; j < 4; j++)
	{
		getline(fin, line);
		cout << line << endl;
		
	} goto FIM;

Cancelar:
	cout << "Teste" << endl;

FIM: 
	cout << "Voltar menu" << endl;
}

*/

void escolhePrato()
{
	string prato;
	fstream ficheiro("Lista Refeicoes.txt");
	string linha;
	int contador = 0;
	string converte;
	wcout << "Por favor insira o nome do prato: " << endl;
	cin >> prato;

	// verifica antes que acabe o ficheiro, talvez um while (!ficheiro.eol())
	while (!ficheiro.eof())
	{
		getline(ficheiro, linha);

		size_t procura;
		procura = linha.find(prato);
		if (procura != string::npos)
		{
			contador++; // faz a soma
			//converte = to_string(contador);
		}
	}
	
	cout << "Esta refei��o foi consumida por " << contador << " aluno(s)";
	
}

void main()
{

	fstream ficheiro("Lista Refeicoes.txt");
	string linha;
	//string opcao;
	int opcao;
	
	int num;			//identificacao para identificar o aluno
	int contador = 0;
	bool acaba = false;
	string prato;
	int convert_opcao; // conversao do int para string

	if (ficheiro.is_open())
	{
		do {
			wcout << "Pretende saber o consumo das refei��es (0 para sair)" << endl;
			wcout << "1. Todos os alunos" << endl;
			wcout << "2. Um determinado aluno." << endl;
			wcout << "Op��o: ";
			cin >> opcao;
			//convert_opcao =  stoi(opcao);
			//convert_Str_2_Int(opcao)
			
		//	switch (convert_opcao)
			switch(opcao)
			{

			case 0: 
				//clrConsole();
				system("CLS");
				wcout << "Escolheu a op��o sair" << endl;
				Sleep(3000);
				//clrConsole();
				system("CLS");
				acaba = true;
				break;


			case 1:
				//contador = 0;
				wcout << "Escolheu a primeira op��o" << endl; // 
				Sleep(3000);
				//clrConsole();
				system("CLS");
				escolhePrato();
				Sleep(3000);
				system("CLS");
				acaba = true;
				break;

			case 2:

				wcout << "Escolheu a segunda op��o" << endl;
				Sleep(3000);
				//clrConsole();
				system("CLS");
				wcout << "Por favor insira a n�mero mecanogr�fico: ";
				cin >> num;
				//num_String = to_string(num); // converte o num para string

				//while (!ficheiro.eof())
				//{
				//	getline(ficheiro, linha);
				//	if (linha == num_String) // se encontrar a identidade do aluno 
				//	{
				//		// mostra a informacao dos pratos que consumiu
				//	}
				//	else
				//	{
				//		wcout << "N�o existe nenhum n�mero como esse" << endl
				//			  << "Ou inseriu um n�mero errado" << endl;
				//		Sleep(3000);
				//		//clrConsole();
				//		system("CLS");
				//	}
				//}
				acaba = true;
				break;

			default:
				wcout << "Op��o Errada" << endl;
				//clrConsole();
				system("CLS");
				Sleep(100);
				
				acaba;
			}
		} while (!acaba);
		cin.ignore();
		cin.sync();
	}
	else wcout << "Erro: Ficheiro inexistente ou est� foi mudado para outro s�tio" << endl;

}